# Drift — Coach de Sueño IA

## Cómo deployar en Netlify (paso a paso)

### 1. Subir a GitHub
1. Creá un repo nuevo en github.com (puede ser privado)
2. Subí todos estos archivos manteniendo la estructura:
   ```
   drift/
   ├── netlify.toml
   ├── public/
   │   └── index.html
   └── netlify/
       └── functions/
           └── chat.js
   ```

### 2. Conectar con Netlify
1. Entrá a netlify.com → "Add new site" → "Import from Git"
2. Seleccioná tu repo de GitHub
3. En "Build settings":
   - Build command: (dejarlo vacío)
   - Publish directory: `public`
4. Clic en "Deploy site"

### 3. Agregar la API Key (IMPORTANTE)
1. En Netlify, andá a tu sitio → Site settings → Environment variables
2. Clic en "Add a variable"
3. Key: `ANTHROPIC_API_KEY`
4. Value: tu API key de Anthropic (la conseguís en console.anthropic.com)
5. Guardá y re-deployá el sitio

### 4. Listo
Tu app va a estar en: `https://tu-sitio.netlify.app`

## Estructura del proyecto
- `public/index.html` — La app completa (frontend)
- `netlify/functions/chat.js` — El proxy seguro a la API de Anthropic
- `netlify.toml` — Configuración de Netlify

## Costo estimado
- Netlify: Gratis (plan free tiene 125k llamadas/mes)
- Anthropic API: ~$0.003 por conversación (muy barato)
